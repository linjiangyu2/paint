<?php
$img = 'https://reject.io/img/22.jpg';
echo '<img src="'.$img.'" alt="防盗链" />';
?>
<?php
    phpinfo();
?>
